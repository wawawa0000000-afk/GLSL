# NERV System Monitor Server v2
# 管理者権限で実行してください

$port = 9999

# HttpListener の URL 予約を先に行う
$null = netsh http add urlacl url="http://localhost:$port/" user="Everyone" 2>$null

$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:$port/")

try {
    $listener.Start()
    Write-Host "OK: サーバー起動成功 http://localhost:$port/stats" -ForegroundColor Green
    Write-Host "停止: Ctrl+C" -ForegroundColor Yellow
} catch {
    Write-Host "ERROR: サーバー起動失敗 - $_" -ForegroundColor Red
    Write-Host "管理者権限で実行されていますか？" -ForegroundColor Yellow
    Read-Host "Enterで終了"
    exit
}

$prevSent = 0; $prevRecv = 0; $prevTime = [DateTime]::Now

# ネットアダプター取得
$adapter = (Get-NetAdapter | Where-Object Status -eq 'Up' | Select-Object -First 1).Name

while ($true) {
    try {
        $ctx = $listener.GetContext()
    } catch { break }

    if ($ctx.Request.Url.AbsolutePath -ne '/stats') {
        $ctx.Response.StatusCode = 404
        $ctx.Response.Close()
        continue
    }

    # CPU
    $cpu = [Math]::Round(
        (Get-Counter '\Processor(_Total)\% Processor Time' -SampleInterval 1 -MaxSamples 1
        ).CounterSamples[0].CookedValue, 1)

    # RAM (Win32_OperatingSystem はKB単位)
    $os     = Get-CimInstance Win32_OperatingSystem
    $totMB  = [Math]::Round($os.TotalVisibleMemorySize / 1024)
    $freMB  = [Math]::Round($os.FreePhysicalMemory      / 1024)
    $usdMB  = $totMB - $freMB

    # GPU
    $gpu = 0
    try {
        $gpu = [Math]::Round(
            ((Get-Counter '\GPU Engine(*engtype_3D)\Utilization Percentage' `
                -ErrorAction Stop).CounterSamples |
             Measure-Object CookedValue -Sum).Sum, 1)
    } catch {}

    # ネット
    $upBps = 0; $dnBps = 0
    try {
        $st  = Get-NetAdapterStatistics -Name $adapter -ErrorAction Stop
        $now = [DateTime]::Now
        $el  = ($now - $prevTime).TotalSeconds
        if ($el -gt 0 -and $prevSent -gt 0) {
            $upBps = [Math]::Max(0, [long](($st.SentBytes     - $prevSent) / $el))
            $dnBps = [Math]::Max(0, [long](($st.ReceivedBytes - $prevRecv) / $el))
        }
        $prevSent = $st.SentBytes; $prevRecv = $st.ReceivedBytes; $prevTime = $now
    } catch {}

    # ディスク
    $disk = 0
    try {
        $disk = [Math]::Min(100, [Math]::Round(
            (Get-Counter '\PhysicalDisk(_Total)\% Disk Time' -ErrorAction Stop
            ).CounterSamples[0].CookedValue, 1))
    } catch {}

    $json  = "{`"cpu`":$cpu,`"gpu`":$gpu,`"usedRamMB`":$usdMB,`"totalRamMB`":$totMB,`"netUpBps`":$upBps,`"netDownBps`":$dnBps,`"disk`":$disk}"
    Write-Host "$(Get-Date -Format 'HH:mm:ss') CPU:$cpu% MEM:$usdMB/$totMB MB GPU:$gpu%"

    $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
    $ctx.Response.ContentType     = 'application/json'
    $ctx.Response.ContentLength64 = $bytes.Length
    $ctx.Response.Headers.Add('Access-Control-Allow-Origin','*')
    $ctx.Response.OutputStream.Write($bytes, 0, $bytes.Length)
    $ctx.Response.Close()
}
